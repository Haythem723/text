package net.diyigemt.meabuttontest.utils;

public class Constant {
  public static final String APP_DATA_FOLDER_NAME = "MeaButton";
  public static final String VOICE_SAVE_FILE_NAME = "voices.json";
  public static final String BASIC_DOWNLOAD_PATH = "https://meamea.moe/voices/";
  public static final String HEADER_HOST = "meamea.moe";
  public static final String HEADER_REFERER = "https://meamea.moe/";
  public static final String HEADER_COOKIE = "__cfduid=db26cdc136438e151851c3a70fd2abf671618560261";
  public static final String HEADER_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.72 Safari/537.36";
  public static final int FILE_NAME_LENGTH = 9;
  public static final int FILE_DESCRIPTION_LENGTH = 12;
}
